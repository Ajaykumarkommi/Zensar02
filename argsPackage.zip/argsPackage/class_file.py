class cdwia:

    def __init__(self, name4, name5, name6):
        self.name4 = name4

        self.name5 = name5

        self.name6 = name6

        def __init__(self, function):
            self.function = function

        def __call__(self, *args):
            self.function(*args)